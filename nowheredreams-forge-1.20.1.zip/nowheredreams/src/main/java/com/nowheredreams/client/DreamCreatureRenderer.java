package com.nowheredreams.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.nowheredreams.CreatureVariant;
import com.nowheredreams.DreamCreature;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Dibuja cada criatura como una lámina con la imagen original (siempre mirando a la cámara),
 * con animaciones dreamcore: balanceo, respiración y glitches ocasionales.
 */
public class DreamCreatureRenderer extends EntityRenderer<DreamCreature> {

    public DreamCreatureRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.3f;
    }

    @Override
    public ResourceLocation getTextureLocation(DreamCreature e) { return e.getVariant().texture; }

    @Override
    public void render(DreamCreature e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        CreatureVariant v = e.getVariant();
        float t = e.tickCount + partialTick;
        float id = e.getId();

        float h = 1.95f * v.height * CreatureVariant.SCALE;
        float w = h * v.aspect;

        // --- animaciones dreamcore ---
        float sway = Mth.sin(t * 0.05f + id) * 3.0f;                 // balanceo lento (grados)
        float breathe = 1.0f + Mth.sin(t * 0.08f + id) * 0.025f;     // respiración (estira la lámina)
        boolean glitch = (((int) t + (int) id) % 70) < 3;            // cada ~3.5 s, 3 ticks de glitch
        float jitterX = glitch ? Mth.sin(t * 9f) * 0.12f : 0f;
        float stretch = glitch ? 1.0f + Mth.sin(t * 13f) * 0.06f : 1.0f;

        ps.pushPose();
        ps.mulPose(this.entityRenderDispatcher.cameraOrientation());
        ps.mulPose(Axis.YP.rotationDegrees(180.0F));
        ps.mulPose(Axis.ZP.rotationDegrees(sway));
        ps.translate(jitterX, 0, 0);

        float hw = w / 2f;
        float top = h * breathe * stretch;

        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(v.texture));
        vertex(vc, m, n, -hw, 0f, 0f, 1f, light);
        vertex(vc, m, n, hw, 0f, 1f, 1f, light);
        vertex(vc, m, n, hw, top, 1f, 0f, light);
        vertex(vc, m, n, -hw, top, 0f, 0f, light);
        ps.popPose();

        super.render(e, yaw, partialTick, ps, buffers, light);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float u, float v, int light) {
        vc.vertex(m, x, y, 0f).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0f, 1f, 0f).endVertex();
    }
}
