package com.nowheredreams.worldgen;

import com.nowheredreams.NowhereDreams;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Colinas redondas, casas retro y molinetes gigantes para la dimensión backrooms_92. */
public final class DreamFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, NowhereDreams.MODID);

    public static final RegistryObject<Feature<NoneFeatureConfiguration>> HILL = FEATURES.register("hill", HillFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> HOUSE = FEATURES.register("house", HouseFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> PINWHEEL = FEATURES.register("pinwheel", PinwheelFeature::new);

    private static void set(WorldGenLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, 2);
    }

    /** Primer hueco libre sobre el suelo (ignora aire y plantas), escaneando desde y=70. */
    private static int surface(WorldGenLevel level, int x, int z) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = 70; y >= level.getMinBuildHeight(); y--) {
            BlockState s = level.getBlockState(p.set(x, y, z));
            if (!s.isAir() && !s.canBeReplaced()) return y + 1;
        }
        return level.getMinBuildHeight();
    }

    // ---------------------------------------------------------------- colinas
    static class HillFeature extends Feature<NoneFeatureConfiguration> {
        HillFeature() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
            WorldGenLevel level = ctx.level();
            BlockPos o = ctx.origin();
            RandomSource rnd = ctx.random();
            int r = 7 + rnd.nextInt(7);
            int hMax = 3 + rnd.nextInt(6);
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > r) continue;
                    int hh = (int) Math.round(hMax * 0.5 * (1 + Math.cos(Math.PI * d / r)));
                    if (hh <= 0) continue;
                    int x = o.getX() + dx, z = o.getZ() + dz;
                    int y0 = surface(level, x, z);
                    for (int i = 0; i < hh; i++)
                        set(level, x, y0 + i, z, (i == hh - 1 ? Blocks.GRASS_BLOCK : Blocks.DIRT).defaultBlockState());
                }
            }
            return true;
        }
    }

    // ---------------------------------------------------------------- casas
    static class HouseFeature extends Feature<NoneFeatureConfiguration> {
        private static final Block[] WALLS = {Blocks.WHITE_CONCRETE, Blocks.YELLOW_CONCRETE, Blocks.PINK_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE};

        HouseFeature() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
            WorldGenLevel level = ctx.level();
            BlockPos o = ctx.origin();
            RandomSource rnd = ctx.random();
            int x0 = o.getX() - 3, z0 = o.getZ() - 3;

            int base = Math.max(Math.max(surface(level, x0, z0), surface(level, x0 + 6, z0)),
                    Math.max(Math.max(surface(level, x0, z0 + 6), surface(level, x0 + 6, z0 + 6)), surface(level, x0 + 3, z0 + 3)));

            BlockState wall = WALLS[rnd.nextInt(WALLS.length)].defaultBlockState();
            BlockState floor = Blocks.OAK_PLANKS.defaultBlockState();
            BlockState found = Blocks.STONE_BRICKS.defaultBlockState();
            BlockState air = Blocks.AIR.defaultBlockState();
            BlockState glass = Blocks.GLASS.defaultBlockState();
            BlockState ridge = Blocks.BRICKS.defaultBlockState();

            for (int dx = 0; dx <= 6; dx++) {
                for (int dz = 0; dz <= 6; dz++) {
                    int x = x0 + dx, z = z0 + dz;
                    int s = surface(level, x, z);
                    for (int y = s - 1; y < base - 1; y++) set(level, x, y, z, found);
                    set(level, x, base - 1, z, floor);

                    boolean edge = dx == 0 || dx == 6 || dz == 0 || dz == 6;
                    for (int h = 0; h < 4; h++) {
                        BlockState st = edge ? wall : air;
                        if (dx == 3 && dz == 0 && h < 2) st = air;                              // puerta abierta
                        boolean window = h == 1 && (((dx == 0 || dx == 6) && dz == 3) || (dx == 3 && dz == 6));
                        if (window) st = glass;
                        set(level, x, base + h, z, st);
                    }

                    // tejado a dos aguas (cumbrera a lo largo de Z)
                    int rh = Math.min(dx, 6 - dx);
                    int ry = base + 4 + rh;
                    if (dx == 3) {
                        set(level, x, ry, z, ridge);
                    } else {
                        Direction up = dx < 3 ? Direction.EAST : Direction.WEST;
                        set(level, x, ry, z, Blocks.BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, up));
                    }
                    if (dz == 0 || dz == 6) // cierra los triángulos de los extremos
                        for (int y = base + 4; y < ry; y++) set(level, x, y, z, wall);
                }
            }
            return true;
        }
    }

    // ---------------------------------------------------------------- molinete gigante
    static class PinwheelFeature extends Feature<NoneFeatureConfiguration> {
        private static final Block[] BLADES = {Blocks.RED_CONCRETE, Blocks.YELLOW_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE, Blocks.LIME_CONCRETE};

        PinwheelFeature() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
            WorldGenLevel level = ctx.level();
            BlockPos o = ctx.origin();
            RandomSource rnd = ctx.random();
            int x = o.getX(), z = o.getZ();

            int s = Math.max(Math.max(surface(level, x, z), surface(level, x + 1, z)),
                    Math.max(surface(level, x, z + 1), surface(level, x + 1, z + 1)));
            int height = 16 + rnd.nextInt(7);
            BlockState pole = Blocks.WHITE_CONCRETE.defaultBlockState();

            for (int dx = 0; dx <= 1; dx++)
                for (int dz = 0; dz <= 1; dz++)
                    for (int y = s - 1; y < s + height; y++) set(level, x + dx, y, z + dz, pole);

            int hubY = s + height;
            BlockState hub = Blocks.ORANGE_CONCRETE.defaultBlockState();
            for (int dx = 0; dx <= 1; dx++)
                for (int dy = -1; dy <= 0; dy++)
                    for (int dz = 0; dz <= 1; dz++) set(level, x + dx, hubY + dy, z + dz, hub);

            double baseAngle = rnd.nextDouble() * Math.PI / 2;
            for (int i = 0; i < 4; i++) {
                double a = baseAngle + i * Math.PI / 2;
                double cos = Math.cos(a), sin = Math.sin(a);
                BlockState color = BLADES[i].defaultBlockState();
                for (int t = 1; t <= 10; t++) {
                    long wMax = Math.max(1, Math.round(t * 0.4));
                    for (int pw = 0; pw <= wMax; pw++) {
                        int bx = x + (int) Math.round(t * cos - pw * sin);
                        int by = hubY + (int) Math.round(t * sin + pw * cos);
                        for (int dz = 0; dz <= 1; dz++) set(level, bx, by, z + dz, color);
                    }
                }
            }
            return true;
        }
    }

    private DreamFeatures() {}
}
