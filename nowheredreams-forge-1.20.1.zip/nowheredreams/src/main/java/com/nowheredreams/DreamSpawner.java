package com.nowheredreams;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** Hace aparecer criaturas al azar alrededor de los jugadores, solo en las dimensiones del mod. */
public class DreamSpawner {
    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel level)) return;
        if (!ModDimensions.isDream(level.dimension()) || level.getGameTime() % 100 != 0) return;

        for (ServerPlayer p : level.players()) {
            int nearby = level.getEntitiesOfClass(DreamCreature.class, p.getBoundingBox().inflate(64)).size();
            if (nearby >= 3 || level.random.nextFloat() > 0.45f) continue;

            CreatureVariant v;
            if (level.dimension() == ModDimensions.BACKROOMS) { // solo Locust, figura blanca y Boca Roja (la más alta)
                float roll = level.random.nextFloat();
                v = roll < 0.5f ? CreatureVariant.STILT : roll < 0.8f ? CreatureVariant.BATH_GIANT : CreatureVariant.RED_MAW;
            } else {
                v = CreatureVariant.values()[level.random.nextInt(CreatureVariant.values().length)];
            }
            double ang = level.random.nextDouble() * Math.PI * 2;
            double dist = 26 + level.random.nextDouble() * 14;
            int x = (int) (p.getX() + Math.cos(ang) * dist);
            int z = (int) (p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(new BlockPos(x, p.getBlockY(), z))) continue;

            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (y <= level.getMinBuildHeight() + 1) continue; // sin suelo

            DreamCreature mob = NowhereDreams.CREATURES.get(v).get().create(level);
            if (mob == null) continue;
            mob.moveTo(x + 0.5, y, z + 0.5, level.random.nextFloat() * 360f, 0f);
            level.addFreshEntity(mob);
        }
    }
}
