package com.nowheredreams;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(NowhereDreams.MODID)
public class NowhereDreams {
    public static final String MODID = "nowheredreams";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<CreatureVariant, RegistryObject<EntityType<DreamCreature>>> CREATURES = new EnumMap<>(CreatureVariant.class);
    public static final Map<CreatureVariant, RegistryObject<Item>> EGGS = new EnumMap<>(CreatureVariant.class);

    public static final RegistryObject<Item> DREAM_KEY = ITEMS.register("dream_key",
            () -> new DreamKeyItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    static {
        for (CreatureVariant v : CreatureVariant.values()) {
            RegistryObject<EntityType<DreamCreature>> type = ENTITIES.register(v.id,
                    () -> EntityType.Builder.<DreamCreature>of((t, l) -> new DreamCreature(t, l, v), MobCategory.MONSTER)
                            .sized(0.6f * v.width * CreatureVariant.SCALE, 1.95f * v.height * CreatureVariant.SCALE)
                            .clientTrackingRange(10)
                            .build(MODID + ":" + v.id));
            CREATURES.put(v, type);
            EGGS.put(v, ITEMS.register(v.id + "_spawn_egg",
                    () -> new ForgeSpawnEggItem(type, v.eggPrimary, v.eggSecondary, new Item.Properties())));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> new ItemStack(DREAM_KEY.get()))
                    .displayItems((params, out) -> {
                        out.accept(DREAM_KEY.get());
                        EGGS.values().forEach(e -> out.accept(e.get()));
                    })
                    .build());

    public NowhereDreams() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        com.nowheredreams.worldgen.DreamFeatures.FEATURES.register(bus);
        bus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.register(new DreamSpawner());
    }

    private void registerAttributes(EntityAttributeCreationEvent e) {
        for (CreatureVariant v : CreatureVariant.values())
            e.put(CREATURES.get(v).get(), DreamCreature.createAttributes(v).build());
    }
}
