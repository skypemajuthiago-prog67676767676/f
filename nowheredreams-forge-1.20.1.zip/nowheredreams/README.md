# Nowhere Dreams (fan mod, Forge 1.20.1 · Java Edition)

Requisitos: JDK 17 y Gradle (o IntelliJ IDEA, que lo descarga solo).

## Compilar
1. Abre la carpeta en IntelliJ IDEA (Open → build.gradle) y espera a que sincronice,
   o en terminal: `gradle genIntellijRuns` y luego `gradle build`.
2. El .jar sale en `build/libs/`. Cópialo a la carpeta `mods` de Forge 1.20.1 (47.x).
3. Para probar directamente: `gradle runClient`.

## Cómo se juega
- Crea la **Llave Onírica** (amatista en cruz + perla de ender al centro) o sácala de la pestaña creativa "Nowhere Dreams".
- Clic derecho: Overworld → Liminal Halls → Dream Void → Beta Lands → Overworld (60 ticks de espera).
- En esas 3 dimensiones aparecen criaturas al azar cerca del jugador. También hay huevos generadores.

## Dónde tocar cosas
- Estadísticas / efectos de cada criatura: `CreatureVariant.java`
- Dibujo y animaciones (balanceo, respiración, glitch): `client/DreamCreatureRenderer.java`
- Niebla, FOV y cámara dreamcore: `client/DreamClientEvents.java`
- Dimensiones: `src/main/resources/data/nowheredreams/dimension*/`
- Imágenes de las criaturas (tus PNG recortados): `assets/nowheredreams/textures/entity/*.png`. Si cambias una, actualiza su `aspect` (ancho/alto) en `CreatureVariant.java`

## Dimensión Backrooms 92
- Ir: `/execute in nowheredreams:backrooms_92 run tp @s 0 30 0` (antes: `/effect give @s minecraft:slow_falling 15`) o con la Llave Onírica.
- Colinas redondas, casas retro y molinetes gigantes. Solo aparecen 3 criaturas: Boca Roja (la más alta), Locust y la figura blanca.
